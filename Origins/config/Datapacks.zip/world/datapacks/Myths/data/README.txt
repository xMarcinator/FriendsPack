Delete "minecraft" folder if unneeded

Delete "origins" folder if trying to replace default origin
